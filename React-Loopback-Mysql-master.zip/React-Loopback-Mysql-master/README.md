# React-Loopback-Mysql
Menghubungkan antara React dengan Loopback+Mysql
